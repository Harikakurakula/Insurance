import { AdminTable } from './admin-table';

describe('AdminTable', () => {
  it('should create an instance', () => {
    expect(new AdminTable()).toBeTruthy();
  });
});
