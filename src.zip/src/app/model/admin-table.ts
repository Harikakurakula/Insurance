export class AdminTable {
      LoginId !: number
        Passwordd !: string
}
