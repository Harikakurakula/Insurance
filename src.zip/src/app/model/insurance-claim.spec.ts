import { InsuranceClaim } from './insurance-claim';

describe('InsuranceClaim', () => {
  it('should create an instance', () => {
    expect(new InsuranceClaim()).toBeTruthy();
  });
});
