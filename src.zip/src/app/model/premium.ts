import * as internal from "stream"

export class Premium {
     PremiumId !: number
     Vehicletype ! :  string
      Age ! : number
     Premium1 !: number
}
