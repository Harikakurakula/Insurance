export class Register {
   Emailid !: string
         Firstname !: string
        Lastname !: string
        Mobilenumber !: string
         Address !: string
        DateofBirth !: Date

}
