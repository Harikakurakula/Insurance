import { InsuranceApplication } from './insurance-application';

describe('InsuranceApplication', () => {
  it('should create an instance', () => {
    expect(new InsuranceApplication()).toBeTruthy();
  });
});
