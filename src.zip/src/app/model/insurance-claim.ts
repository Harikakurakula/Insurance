export class InsuranceClaim {

   ClaimNo !: number
          ClaimReason !: string
        Policyid !: number
         Claimstatus !: boolean
       Amount  !: number
        Appid !: number

}
