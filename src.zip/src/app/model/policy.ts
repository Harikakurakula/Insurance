export class Policy {

     PolicyId !: number
     PolicyDate !: Date
   Appid !: number
     Pstatus !: boolean
     Policyamount !: number
}
