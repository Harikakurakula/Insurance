import { Premium } from './premium';

describe('Premium', () => {
  it('should create an instance', () => {
    expect(new Premium()).toBeTruthy();
  });
});
