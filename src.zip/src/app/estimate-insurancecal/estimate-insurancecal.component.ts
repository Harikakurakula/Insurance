import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estimate-insurancecal',
  templateUrl: './estimate-insurancecal.component.html',
  styleUrls: ['./estimate-insurancecal.component.css']
})
export class EstimateInsurancecalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
