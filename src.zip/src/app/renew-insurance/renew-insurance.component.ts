import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-renew-insurance',
  templateUrl: './renew-insurance.component.html',
  styleUrls: ['./renew-insurance.component.css']
})
export class RenewInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
