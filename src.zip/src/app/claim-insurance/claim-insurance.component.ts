import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-insurance',
  templateUrl: './claim-insurance.component.html',
  styleUrls: ['./claim-insurance.component.css']
})
export class ClaimInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
